package com.test.board.model.dao;

import java.util.List;

import com.test.board.model.dto.Product;

public interface ProductMapper {
	public List<Product> getProductAll();
}
