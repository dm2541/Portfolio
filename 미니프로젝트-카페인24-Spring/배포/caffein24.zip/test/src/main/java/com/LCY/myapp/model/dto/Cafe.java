package com.LCY.myapp.model.dto;

import lombok.Data;

@Data
public class Cafe {
	private String cafe_code;
	private String cafe_name;
	private String cafe_addr;
	private String cafe_tel;
	private double cafe_star;
	private String cafe_img;

}
