package com.test.board.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.test.board.model.dao.ProductMapper;
import com.test.board.model.dto.Product;

@Controller
public class ProductController {
	
	@Autowired
	private ProductMapper productMapper;
	
	@RequestMapping(value = "productList.do", method = RequestMethod.POST)
	public String getProductAll(Model model) {
		List<Product> productList = productMapper.getProductAll();
		model.addAttribute("productList", productList);
		return "productList";
	}

}
